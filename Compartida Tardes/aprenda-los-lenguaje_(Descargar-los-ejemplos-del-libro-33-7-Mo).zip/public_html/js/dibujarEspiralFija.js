// lugar de dibujo.
var ctx;

// para centrar la espiral
var decalX = 300;
var decalY = 300;

// para la forma de espiral
var MIN_SPIR = 100;
var MAX_SPIR = 300;
var numCirculos = MIN_SPIR;
var anguloInicial = 0;
var incrementoAngulo = Math.PI / 60;

// start (body.onload)
function dibujar() {
    var canvas = document.getElementById("spire_id");
    ctx = canvas.getContext("2d");
    dibujarEspiral();
}

function dibujarEspiral() {
    // centramos
    ctx.translate(decalX, decalY);

    // escribimos a partir del centro.
    ctx.moveTo(0, 0);

    //------------------------------------
    // init
    // 
    // el paso que hace agrandar el c�rculo.
    var incrementoTamanyo = 0.9;
    // tama�o inicial
    var tamanyo = 0;

    // �ngulo que evoluciona en redondo
    var theta = anguloInicial;

    // n�mero de vueltas
    var maxLoop = numCirculos * Math.PI;

    // tama�o del c�rculo
    var k = numCirculos / MAX_SPIR;

    // la espiral    
    while (theta < maxLoop) {
        ctx.lineTo(k * tamanyo * Math.cos(theta), k * tamanyo * Math.sin(theta));
        theta += incrementoAngulo;
        tamanyo += incrementoTamanyo;

    }
    ctx.stroke();
}




