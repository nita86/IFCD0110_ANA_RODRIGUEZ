
function proveedor(elVinculo) {
    var elProveedor = elVinculo.getAttribute('data-provider');
    var elProveedor2 = elVinculo.dataset.provider;
    alert(elProveedor);
}
