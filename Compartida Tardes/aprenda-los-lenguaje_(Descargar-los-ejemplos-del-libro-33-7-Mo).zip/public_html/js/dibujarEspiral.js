var canvas;
var ctx;
var intervId;
var numInter = 0;
var girar_bool = true;

// para centrar la espiral
var decalX = 300;
var decalY = 300;

// para el bucle
var MIN_SPIR = 100;
var MAX_SPIR = 300;
var numEspi = MIN_SPIR;
var sinCrecimiento = 1;
var dir = "arriba";
var anguloInicial = 0;
var dirAnguloInicial = 'izquierda';
var sinAnguloInicial = Math.PI / 180;
var incrementoAngulo = Math.PI / 60;

// para los FPS
var filterStrength = 20;
var frameTime = 0, lastLoop = new Date(), thisLoop;


// start (body.onload)
function dibujar() {
    canvas = document.getElementById("spire_id");
    ctx = canvas.getContext("2d");
    masRapido();
    intervId = setInterval(reDibuja, 1);
}


// event bar espace : start/stop
$(function() {
    $(document).keydown(function(evt) {
        if (evt.keyCode === 32) {
            if (girar_bool) {
                girar_bool = false;
                clearInterval(intervId);
            } else {
                girar_bool = true;
                intervId = setInterval(reDibuja, 1);
            }
        }
        if (evt.keyCode === 27) {
            girar_bool = false;
            clearInterval(intervId);
        }
    });
});


$(document).ready(function() {

    // para Full Screen
    $('.fs-button').on('click', function() {
        var elem = document.getElementById('fullscreen');
        if (document.webkitFullscreenElement) {
            decalX = 300;
            decalY = 300;
            $('#spire_id').attr('height', '600').attr('width', '600');
            $('.fs-button').css('left', '570px');
            $('.mas_btn').css('left', '540px');
            $('.menos_btn').css('left', '510px');
            $('.stop_btn').css('left', '480px');

            document.webkitCancelFullScreen();
        } else {
            elem.webkitRequestFullScreen();
            decalX = screen.width / 2;
            decalY = screen.height / 2;
            $('#spire_id').attr('height', screen.height).attr('width', screen.width);
            $('.fs-button').css('left', (screen.width - 30) + 'px');
            $('.mas_btn').css('left', (screen.width - 60) + 'px');
            $('.menos_btn').css('left', (screen.width - 90) + 'px');
            $('.stop_btn').css('left', (screen.width - 120) + 'px');
        }
    });

    $('.menos_btn').on('click', function() {
        menosRapido();
    });

    $('.mas_btn').on('click', function() {
        masRapido();
    });

    $('.stop_btn').on('click', function() {
        stopSpir();
    });
});

function masRapido() {
    if (!girar_bool) {
        girar_bool = true;
        intervId = setInterval(reDibuja, 1);
    }
    sinAnguloInicial += Math.PI / 30;
}
function menosRapido() {
    if (!girar_bool) {
        girar_bool = true;
        intervId = setInterval(reDibuja, 1);
    }
    sinAnguloInicial -= Math.PI / 30;
}

function stopSpir() {
    sinAnguloInicial = 0;
    girar_bool = false;
    clearInterval(intervId);
}

function reDibuja() {
    // posici�n del punto central
    if (anguloInicial >= 8 * Math.PI) {
        dirAnguloInicial = 'derecha';
    } else if (anguloInicial < 0) {
        dirAnguloInicial = 'izquierda';
    }

    if (dirAnguloInicial === 'derecha') {
        anguloInicial = 0;
        dirAnguloInicial = 'izquierda';
    } else {
        anguloInicial += sinAnguloInicial;
    }

    //
    dibujarEspiral(numEspi); //(numEspi - MIN_SPIR) / 3 + 10);
}




function dibujarEspiral(numCirculos) {
    // borra
    canvas.width = canvas.width;

    // centra
    ctx.translate(decalX, decalY);

    //ctx.fillStyle = "red";
    //ctx.beginPath();
    ctx.moveTo(0, 0);

    // init
    var incrementoTamanyo = 0.9;
    var theta = anguloInicial;
    var tamanyo = 0;

    // loop
    var maxLoop = numCirculos * Math.PI;

    // define el tama�o del circulo
    var k = (numCirculos / MAX_SPIR) * 1;
    // la spirale    
    while (theta < maxLoop) {
        ctx.lineTo(k * tamanyo * Math.cos(theta), k * tamanyo * Math.sin(theta));
        theta += incrementoAngulo;
        tamanyo += incrementoTamanyo;
    }

    var x0 = k * (tamanyo - incrementoTamanyo) * Math.cos(theta - incrementoAngulo);
    var y0 = k * (tamanyo - incrementoTamanyo) * Math.sin(theta - incrementoAngulo);

    // evita un trazo entre el primero y el ultimo...
    ctx.moveTo(0, 0);

    // se retoma a 90�
    theta = anguloInicial + Math.PI / 2;
    tamanyo = 0;
    // la espiral
    while (theta < maxLoop) {
        ctx.lineTo(k * tamanyo * Math.cos(theta), k * tamanyo * Math.sin(theta));
        theta += incrementoAngulo;
        tamanyo += incrementoTamanyo;
    }

    // cierra el conjunto
    var ptitDecal = 10;
    ctx.lineTo(x0, y0);
    ctx.stroke();

// shadow
    ctx.shadowOffsetX = 4;
    ctx.shadowOffsetY = 4;
    ctx.shadowBlur = 5;
    ctx.shadowColor = 'rgba(0,0,0,0.6)';

    // calc FPS
    var thisFrameTime = (thisLoop = new Date) - lastLoop;
    frameTime += (thisFrameTime - frameTime) / filterStrength;
    lastLoop = thisLoop;

    var text = (1000 / frameTime).toFixed(1) + " fps";
    ctx.font = "12pt Verdana";
    ctx.textAlign = "left";
    ctx.textBaseline = 'top';
    ctx.fillStyle = 'rgb(0,0,0)';
    ctx.fillText(text, -decalX, -decalY);
}
