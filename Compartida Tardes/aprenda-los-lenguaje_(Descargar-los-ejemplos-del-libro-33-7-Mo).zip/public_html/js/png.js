var pattTernColor = new Array();

//------------------------------------
//
// Arco iris de colores
//
var frecuencia = .2;
var RFrecuencia = Math.PI / 9;
var VFrecuencia = Math.PI / 17;
var BFrecuencia = Math.PI / 4;
for (var i = 0; i < 20; ++i)
{
    var r = Math.round(Math.sin(RFrecuencia * i) * 70 + 180);
    var g = Math.round(Math.sin(VFrecuencia * i) * 70 + 180);
    var b = Math.round(Math.sin(BFrecuencia * i) * 70 + 180);
    var txt = 255;
    if ((r + g + b) > 100) {
        txt = 0;
    }
    pattTernColor[i] = {};
    pattTernColor[i].r = r;
    pattTernColor[i].g = g;
    pattTernColor[i].b = b;
    pattTernColor[i].t = txt;
}


function crearPng() {

// generaci�n de PNG asociado.
    var tama�oDiagImg = 10;
    var p;
    var out = '';
    
    for (var numCol = 0; numCol < pattTernColor.length; numCol++) {
        p = new PNGlib(tama�oDiagImg, tama�oDiagImg, 256);

        for (var x = 0; x < tama�oDiagImg; x++) {
            for (var y = 0; y < tama�oDiagImg; y++) {
                var textColor = p.color(pattTernColor[numCol].t, pattTernColor[numCol].t, pattTernColor[numCol].t, 255);
                var fillColor = p.color(pattTernColor[numCol].r, pattTernColor[numCol].g, pattTernColor[numCol].b, 200);
                
                switch (numCol % 5) {
                    case 0:
                        if (x === y) { // patr�n : \
                            p.buffer[p.index(x, y)] = textColor;
                        } else {
                            p.buffer[p.index(x, y)] = fillColor;
                        }
                        break;
                    case 1 :
                        if ((tama�oDiagImg - 1) - x === y) { // patr�n : /
                            p.buffer[p.index(x, y)] = textColor;
                        } else {
                            p.buffer[p.index(x, y)] = fillColor;
                        }
                        break;

                    case 2 :
                        if (x === 2 || x === 7) { // patr�n : |
                            p.buffer[p.index(x, y)] = textColor;
                        } else {
                            p.buffer[p.index(x, y)] = fillColor;
                        }
                        break;
                    case 3 :
                        if (y === 2 || y === 7) { // patr�n : _
                            p.buffer[p.index(x, y)] = textColor;
                        } else {
                            p.buffer[p.index(x, y)] = fillColor;
                        }
                        break;
                    case 4 :
                        if (tama�oDiagImg - x === y || x === y) { // patr�n : x
                            p.buffer[p.index(x, y)] = textColor;
                        } else {
                            p.buffer[p.index(x, y)] = fillColor;
                        }
                        break;
                }

            }
        }
        out += '<img id="imgColl_' + numCol + '" src="data:image/png;base64,' + p.getBase64() + '">&nbsp;';
    }

    document.getElementById('pngg').innerHTML = out;
}
