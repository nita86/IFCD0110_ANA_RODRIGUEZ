function cierreVentana(){
	document.getElementById('angulo').style.display='none';
}

