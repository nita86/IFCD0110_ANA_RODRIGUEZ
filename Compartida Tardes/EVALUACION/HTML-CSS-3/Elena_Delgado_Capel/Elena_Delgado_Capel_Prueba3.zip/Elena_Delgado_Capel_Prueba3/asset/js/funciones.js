

function inicio{

	document.getElementById('portal').onmousedown.limiteNumero;
}

function limiteNumero{
	var numero='';
	numero=true;
	switch(true){
		case(numero<1||numero>50)
		alert('elija entre un número entre el 1 y el 50');
	} break;
} 