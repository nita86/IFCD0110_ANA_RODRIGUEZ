

function cambio_envia(){
	
	
	document.getElementById('envia').style.backgroundColor= 'RGB(70, 130, 180)';

}
function cambio_limpia(){
	
	document.getElementById('limpia').style.backgroundColor= 'RGB(70, 130, 180)';
}

function vuelve_color(){
	document.getElementById('envia').style.backgroundColor= 'RGB(176, 196, 222)';
	document.getElementById('limpia').style.backgroundColor='RGB(176, 196, 222)';
}

