window.onload = inicio;

function inicio(){
  document.getElementById('clickHere').onmouseover = cambio;
}

function cambio(){
  document.getElementById('clickHere').onmouseover = pointer;
}
